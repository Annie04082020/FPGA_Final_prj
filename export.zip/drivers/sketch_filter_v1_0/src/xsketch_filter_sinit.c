// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xsketch_filter.h"

extern XSketch_filter_Config XSketch_filter_ConfigTable[];

XSketch_filter_Config *XSketch_filter_LookupConfig(u16 DeviceId) {
	XSketch_filter_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSKETCH_FILTER_NUM_INSTANCES; Index++) {
		if (XSketch_filter_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSketch_filter_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSketch_filter_Initialize(XSketch_filter *InstancePtr, u16 DeviceId) {
	XSketch_filter_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSketch_filter_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSketch_filter_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

