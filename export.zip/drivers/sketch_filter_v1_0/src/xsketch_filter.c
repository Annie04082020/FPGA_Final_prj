// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xsketch_filter.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSketch_filter_CfgInitialize(XSketch_filter *InstancePtr, XSketch_filter_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSketch_filter_Start(XSketch_filter *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSketch_filter_ReadReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSketch_filter_WriteReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSketch_filter_IsDone(XSketch_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSketch_filter_ReadReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSketch_filter_IsIdle(XSketch_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSketch_filter_ReadReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSketch_filter_IsReady(XSketch_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSketch_filter_ReadReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSketch_filter_EnableAutoRestart(XSketch_filter *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSketch_filter_WriteReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSketch_filter_DisableAutoRestart(XSketch_filter *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSketch_filter_WriteReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_AP_CTRL, 0);
}

void XSketch_filter_Set_rows(XSketch_filter *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSketch_filter_WriteReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_ROWS_DATA, Data);
}

u32 XSketch_filter_Get_rows(XSketch_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSketch_filter_ReadReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_ROWS_DATA);
    return Data;
}

void XSketch_filter_Set_cols(XSketch_filter *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSketch_filter_WriteReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_COLS_DATA, Data);
}

u32 XSketch_filter_Get_cols(XSketch_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSketch_filter_ReadReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_COLS_DATA);
    return Data;
}

void XSketch_filter_Set_src_mem(XSketch_filter *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSketch_filter_WriteReg(InstancePtr->Control_r_BaseAddress, XSKETCH_FILTER_CONTROL_R_ADDR_SRC_MEM_DATA, (u32)(Data));
    XSketch_filter_WriteReg(InstancePtr->Control_r_BaseAddress, XSKETCH_FILTER_CONTROL_R_ADDR_SRC_MEM_DATA + 4, (u32)(Data >> 32));
}

u64 XSketch_filter_Get_src_mem(XSketch_filter *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSketch_filter_ReadReg(InstancePtr->Control_r_BaseAddress, XSKETCH_FILTER_CONTROL_R_ADDR_SRC_MEM_DATA);
    Data += (u64)XSketch_filter_ReadReg(InstancePtr->Control_r_BaseAddress, XSKETCH_FILTER_CONTROL_R_ADDR_SRC_MEM_DATA + 4) << 32;
    return Data;
}

void XSketch_filter_Set_dst_mem(XSketch_filter *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSketch_filter_WriteReg(InstancePtr->Control_r_BaseAddress, XSKETCH_FILTER_CONTROL_R_ADDR_DST_MEM_DATA, (u32)(Data));
    XSketch_filter_WriteReg(InstancePtr->Control_r_BaseAddress, XSKETCH_FILTER_CONTROL_R_ADDR_DST_MEM_DATA + 4, (u32)(Data >> 32));
}

u64 XSketch_filter_Get_dst_mem(XSketch_filter *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSketch_filter_ReadReg(InstancePtr->Control_r_BaseAddress, XSKETCH_FILTER_CONTROL_R_ADDR_DST_MEM_DATA);
    Data += (u64)XSketch_filter_ReadReg(InstancePtr->Control_r_BaseAddress, XSKETCH_FILTER_CONTROL_R_ADDR_DST_MEM_DATA + 4) << 32;
    return Data;
}

void XSketch_filter_InterruptGlobalEnable(XSketch_filter *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSketch_filter_WriteReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_GIE, 1);
}

void XSketch_filter_InterruptGlobalDisable(XSketch_filter *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSketch_filter_WriteReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_GIE, 0);
}

void XSketch_filter_InterruptEnable(XSketch_filter *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSketch_filter_ReadReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_IER);
    XSketch_filter_WriteReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_IER, Register | Mask);
}

void XSketch_filter_InterruptDisable(XSketch_filter *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSketch_filter_ReadReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_IER);
    XSketch_filter_WriteReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSketch_filter_InterruptClear(XSketch_filter *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSketch_filter_WriteReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_ISR, Mask);
}

u32 XSketch_filter_InterruptGetEnabled(XSketch_filter *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSketch_filter_ReadReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_IER);
}

u32 XSketch_filter_InterruptGetStatus(XSketch_filter *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSketch_filter_ReadReg(InstancePtr->Control_BaseAddress, XSKETCH_FILTER_CONTROL_ADDR_ISR);
}

