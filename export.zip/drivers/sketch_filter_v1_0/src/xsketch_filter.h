// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XSKETCH_FILTER_H
#define XSKETCH_FILTER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xsketch_filter_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
} XSketch_filter_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
    u32 IsReady;
} XSketch_filter;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XSketch_filter_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XSketch_filter_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XSketch_filter_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XSketch_filter_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XSketch_filter_Initialize(XSketch_filter *InstancePtr, u16 DeviceId);
XSketch_filter_Config* XSketch_filter_LookupConfig(u16 DeviceId);
int XSketch_filter_CfgInitialize(XSketch_filter *InstancePtr, XSketch_filter_Config *ConfigPtr);
#else
int XSketch_filter_Initialize(XSketch_filter *InstancePtr, const char* InstanceName);
int XSketch_filter_Release(XSketch_filter *InstancePtr);
#endif

void XSketch_filter_Start(XSketch_filter *InstancePtr);
u32 XSketch_filter_IsDone(XSketch_filter *InstancePtr);
u32 XSketch_filter_IsIdle(XSketch_filter *InstancePtr);
u32 XSketch_filter_IsReady(XSketch_filter *InstancePtr);
void XSketch_filter_EnableAutoRestart(XSketch_filter *InstancePtr);
void XSketch_filter_DisableAutoRestart(XSketch_filter *InstancePtr);

void XSketch_filter_Set_rows(XSketch_filter *InstancePtr, u32 Data);
u32 XSketch_filter_Get_rows(XSketch_filter *InstancePtr);
void XSketch_filter_Set_cols(XSketch_filter *InstancePtr, u32 Data);
u32 XSketch_filter_Get_cols(XSketch_filter *InstancePtr);
void XSketch_filter_Set_src_mem(XSketch_filter *InstancePtr, u64 Data);
u64 XSketch_filter_Get_src_mem(XSketch_filter *InstancePtr);
void XSketch_filter_Set_dst_mem(XSketch_filter *InstancePtr, u64 Data);
u64 XSketch_filter_Get_dst_mem(XSketch_filter *InstancePtr);

void XSketch_filter_InterruptGlobalEnable(XSketch_filter *InstancePtr);
void XSketch_filter_InterruptGlobalDisable(XSketch_filter *InstancePtr);
void XSketch_filter_InterruptEnable(XSketch_filter *InstancePtr, u32 Mask);
void XSketch_filter_InterruptDisable(XSketch_filter *InstancePtr, u32 Mask);
void XSketch_filter_InterruptClear(XSketch_filter *InstancePtr, u32 Mask);
u32 XSketch_filter_InterruptGetEnabled(XSketch_filter *InstancePtr);
u32 XSketch_filter_InterruptGetStatus(XSketch_filter *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
